document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('climaForm');
    const resultadoDiv = document.getElementById('climaResultado');

    form.addEventListener('submit', async(e) => {
        e.preventDefault();

        const ciudadInput = document.getElementById('ciudadInput').value.trim();
        const latInput = document.getElementById('latInput').value.trim();
        const lonInput = document.getElementById('lonInput').value.trim();

        // Validación para verificar si se ingresa ciudad o coordenadas
        if (ciudadInput || (latInput && lonInput)) {
            try {
                let response;

                // Si hay ciudad, consulta por nombre de ciudad con el parámetro lang=es para obtener la descripción en español
                if (ciudadInput) {
                    response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${ciudadInput}&appid=9e122cd782b2d0333f5fe4e7fa192062&units=metric&lang=es`);
                }
                // Si hay coordenadas, consulta por latitud y longitud con el parámetro lang=es
                else if (latInput && lonInput) {
                    response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?lat=${latInput}&lon=${lonInput}&appid=9e122cd782b2d0333f5fe4e7fa192062&units=metric&lang=es`);
                }

                mostrarClima(response.data);
                cambiarColorFondo(response.data.weather[0].description); // Cambiar el fondo de acuerdo al clima
                hablar(`El clima en ${response.data.name} es de ${response.data.main.temp.toFixed(1)} grados Celsius. Estado: ${response.data.weather[0].description}.`);
            } catch (error) {
                mostrarError('Ha ocurrido un error al obtener el clima.');
                hablar('Lo siento, hubo un error al obtener la información del clima.');
            }
        } else {
            mostrarError('Por favor ingrese una ciudad o coordenadas válidas.');
            hablar('Por favor ingrese una ciudad o coordenadas válidas.');
        }
    });
});

function mostrarClima(data) {
    const resultadoDiv = document.getElementById('climaResultado');
    resultadoDiv.innerHTML = `
        <div class="card">
            <div class="card-header">Clima de ${data.name}</div>
            <div class="card-body">
                <p><strong>Temperatura:</strong> ${data.main.temp.toFixed(2)}°C</p>
                <p><strong>Ciudad:</strong> ${data.name}, ${data.sys.country}</p>
                <p><strong>Estado del tiempo:</strong> ${data.weather[0].description}</p>
                <img src="http://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png" alt="${data.weather[0].description}">
            </div>
        </div>
    `;
}

function mostrarError(mensaje) {
    const resultadoDiv = document.getElementById('climaResultado');
    resultadoDiv.innerHTML = `<div class="alert alert-danger">${mensaje}</div>`;
}

// Función para cambiar el color de fondo dependiendo del clima
function cambiarColorFondo(clima) {
    const body = document.body;

    // Limpiar cualquier clase de fondo anterior
    body.className = '';

    // Convertir el clima a minúsculas para hacer la comparación más robusta
    const descripcion = clima.toLowerCase();

    // Cambiar el color de fondo dependiendo del clima
    if (descripcion.includes("cielo claro") || descripcion.includes("despejado")) {
        body.style.backgroundColor = '#FFEB3B'; // Color amarillo claro para cielos despejados
    } else if (descripcion.includes("nublado") || descripcion.includes("nubes")) {
        body.style.backgroundColor = '#9E9E9E'; // Color gris para nublado
    } else if (descripcion.includes("lluvia") || descripcion.includes("precipitación")) {
        body.style.backgroundColor = '#2196F3'; // Color azul para lluvia
    } else if (descripcion.includes("tormenta") || descripcion.includes("tempestad")) {
        body.style.backgroundColor = '#FF5722'; // Color naranja para tormenta
    } else if (descripcion.includes("nieve") || descripcion.includes("nevando")) {
        body.style.backgroundColor = '#B3E5FC'; // Color azul muy claro para nieve
    } else {
        // Fondo predeterminado si el clima no coincide con los casos anteriores
        body.style.backgroundColor = '#80CBC4'; // Color verde claro como fondo predeterminado
    }
}

// Función para hablar el mensaje utilizando la API de Speech Synthesis
function hablar(mensaje) {
    const message = new SpeechSynthesisUtterance(mensaje);
    message.lang = 'es-ES'; // Establece el idioma en español
    speechSynthesis.speak(message);
}